from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm


def ab(request):
    return render(request, 'main/base.html')


def about(request):
    return render(request, 'main/about.html')


def blank(request):
    return render(request, 'main/blank.html')

def pano(request):
    return render(request, 'main/pano.html')


def list(request):
    return render(request, 'main/list.html')


def list_astro(request):
    return render(request, 'main/list_astro.html')


def list_bio(request):
    return render(request, 'main/list_bio.html')


def list_ch(request):
    return render(request, 'main/list_ch.html')


def list_math(request):
    return render(request, 'main/list_math.html')


def list_phys(request):
    return render(request, 'main/list_phys.html')

def login(request):
     return render(request, 'registration/login.html')

def index(request):
    return render(request, 'user/index.html')

def register(request):
    if request.method == ('POST'):
        form = UserCreationForm(request.POST)

        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            password
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('main/base.html')
    else:
        form = UserCreationForm()
    context = {'form': form}
    return render(request, 'registration/register.html', context)

