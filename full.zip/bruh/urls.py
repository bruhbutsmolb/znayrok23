from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.ab, name='home'),
    path('about', views.about, name='about'),
    path('blank', views.blank, name='blank'),
    path('pano', views.pano, name='pano'),
    path('list', views.list, name='list'),
    path('list_astro', views.list_astro, name='list_astro'),
    path('list_bio', views.list_bio, name='list_bio'),
    path('list_ch', views.list_ch, name='list_ch'),
    path('list_math', views.list_math, name='list_math'),
    path('list_phys', views.list_phys, name='list_phys'),
    path('list_phys', views.list_phys, name='list_phys'),
    path('login', views.login, name='login'),
    path('index', views.index, name='index'),
    path('register', views.register, name='register')
]
