from django.apps import AppConfig


class BruhConfig(AppConfig):
    name = 'bruh'
